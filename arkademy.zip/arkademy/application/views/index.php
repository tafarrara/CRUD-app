<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arkademy</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo base_url('asset/css/bootstrap.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/animate.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/style.css') ?>" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet" type='text/css'>

        <!-- Template js -->
        <script src="<?php echo base_url('asset/js/jquery-2.1.1.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jquery.appear.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jqBootstrapValidation.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/modernizr.custom.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/script.js') ?>"></script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>
        <nav style="padding-right: 1.5em; padding-top: 1em; float: right;">
           <?php if (isset($this->session->userdata['login'])) { ?>
               <a class="" href="<?php echo base_url('dasboard/logout') ?>" >
                    Logout <i class="fa fa-sign-out"></i>
                </a>
           <?php }else{ ?>
                <a class="" href="<?php echo base_url('dasboard/login') ?>">
                    Login <i class="fa fa-sign-out"></i>
                </a>
           <?php } ?>
        </nav>

        <!-- Start Logo Section -->
        <br><br>
        <section id="logo-section" class="text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo text-center">
                            <h1><a href="<?php echo base_url()?>">Arkademy</a></h1>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Logo Section -->

        <!-- Start Main Body Section -->
        <div class="mainbody-section text-center">
            <div class="container">
                <div class="row">

                    <div class="col-md-3">
                        <div class="menu-item blue">
                            <a href="produk">
                                <p>Produk</p>
                            </a>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!-- End Main Body Section -->

    </body>
</html>
