<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arkademy</title>

        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
        <style type="text/css"></style>
        <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
</head>
<body onload="window.print()">
<div style="float: right; padding-top: 1em">
    <button class="btn btn-primary hidden-print" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
    <button id="tutup" class="btn btn-primary hidden-print" onclick="close()"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Close</button>
</div>
    <center>
        <div class="container" style="background: white; padding-top:1em">
            <table width="100%">
                  <tr style="border-bottom:2px solid">
                    <td><p><b>RECORD PRODUK <?php echo $this->session->userdata['produk'] ?><br>
                        </p></td>
                    <td style="text-align:right"><img src="<?php echo base_url('asset/images/logo.png') ?>" style="width: 18em"></td>
                  </tr>
            <table>
            <br><br>
                <table id="tabeldata" width="100%" border="0" class="table  table-bordered" style="text-align:center">
                    <thead style="center;background: #337ab7;color: white;">
                      <tr>
                          <td>No.</td>
                          <td>Nama Produk</td>
                          <td>Keterangan</td>
                          <td>Harga</td>
                          <td>Jumlah</td>
                      </tr>
                  </thead>
                  <tbody style="background: #fff">
                      <?php
                      $no = 1;
                      foreach ($produk as $key) {
                          $submenu = $key->SubMenu;
                          ?>
                          <tr>
                              <td data-title="No."><?php echo $no++ ?></td>
                              <td data-title="Nama Produk"><?php echo $key->nama_produk ?></td>
                              <td data-title="Keterangan"><?php echo $key->keterangan ?></td>
                              <td data-title="Harga"><?php echo $key->harga ?></td>
                              <td data-title="Jumlah"><?php echo $key->jumlah ?></td>
                          </tr>

                                <?php } ?>
                    </tbody>
                </table>
            </table>
        </div>
    </center>
    <script type="text/javascript">
        function myFunction() {
            window.print();
        }
        $(function(){
         $('#tutup').on('click',function(){
            window.location.href = "<?php $sesion = $this->session->userdata['produk']; $goto = "produk/".$sesion; echo base_url($goto); ?>";
         });
        });
        </script>
</body>
</html>
