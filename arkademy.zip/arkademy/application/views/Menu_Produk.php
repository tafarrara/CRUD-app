<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arkademy</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo base_url('asset/css/bootstrap.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/animate.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/style.css') ?>" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet" type='text/css'>

        <!-- Template js -->
        <script src="<?php echo base_url('asset/js/jquery-2.1.1.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jquery.appear.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jqBootstrapValidation.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/modernizr.custom.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/script.js') ?>"></script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

        <!-- Start Feature Section -->
        <div class="section-modal">
            <div>
                <div class="close-modal" data-dismiss="modal">
                    <a href="<?php echo base_url() ?>"><img src="asset/images/close.png"></a>
                </div>

                <div class="container" style="margin: auto; width: 50%; padding-top: 5em">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3>Produk</h3>
                            <p>Data produk</p>
                        </div>
                    </div>
                    <div class="row text-center">
                        <div class="col-md-12">
                            <div class="menu-item blue">
                                <a href="<?php echo base_url('produk/prod') ?>">
                                    <p>MK</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Monitoring-Aproval-Material Section -->
    </body>
</html>
