<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arkademy</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo base_url('asset/css/bootstrap.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/animate.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/style.css') ?>" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet" type='text/css'>
        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

        <!-- Template js -->
        <script src="<?php echo base_url('asset/js/jquery-2.1.1.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jquery.appear.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jqBootstrapValidation.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/modernizr.custom.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/script.js') ?>"></script>

        <!--Tabel -->
        <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#tabeldata').DataTable();
            });
        </script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

        <!-- Start Feature Section -->
        <div class="section-modal">
            <div>
                <div class="close-modal" data-dismiss="modal">
                    <a href="<?php echo base_url('produk') ?>"><img src="<?php echo base_url('asset/images/close.png') ?> "></a>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3>Produk <?php echo $this->session->userdata['produk'] ?> </h3>
                            <p>Data Produk</p>
                        </div>
                    </div>
                    <div class="btn-toolbar" style="float: right; margin-top: 3em">
                        <?php if (isset($this->session->userdata['login'])) { ?>
                        <a href="<?php echo base_url('cetakData/produk') ?>" class="fa fa-print"><b> Print Record</b></a>
                        <a href="#form-produk" data-toggle="modal" class="fa fa-plus"><b> Masukkan Data</b></a>
                        <?php } ?>
                    </div>
                    <div id="no-more-tables">
                        <table id="tabeldata" width="100%" class="table-bordered table-striped table-condensed cf">
                            <thead class="cf" style="background: #337ab7;color: white; text-align: center">
                                  <td>No.</td>
                                  <td>Nama Produk</td>
                                  <td>Keterangan</td>
                                  <td>Harga</td>
                                  <td>Jumlah</td>
                                    <?php if (isset($this->session->userdata['login'])) { ?>
                                        <td>Action</td>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody style="background: #fff">
                                <?php
                                $no = 1;
                                foreach ($produk as $key) {
                                    $submenu = $key->SubMenu;
                                    ?>
                                    <tr>
                                          <td data-title="No."><?php echo $no++ ?></td>
                                          <td data-title="Nama Produk"><?php echo $key->nama_produk ?></td>
                                          <td data-title="Keterangan"><?php echo $key->keterangan ?></td>
                                          <td data-title="Harga"><?php echo $key->harga ?></td>
                                          <td data-title="Jumlah"><?php echo $key->jumlah ?></td>
                                        <?php if (isset($this->session->userdata['login'])) { ?>
                                            <td data-title="Action" style="width: 10em; text-align: center;">
                                              <a href="edit/<?php echo $key->id ?>" class="fa fa-edit"></a>
                                              <span style="display:inline-block; width:1.5em;"></span>
                                              <a href="hapus/<?php echo $key->id ?>" class="fa fa-trash"></a></td>
                                        <?php } ?>
                                    </tr>

                                <?php } ?>
                            </tbody>
                        </table>
                    </div><!-- /.row -->
                </div>
            </div>
        </div>
        <!-- End Feature Section -->

        <!-- Start form-produk Section -->
        <div class="section-modal modal fade" id="form-produk" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>

                <div class="container" style="margin: auto; width: 50%">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3> PRODUK </h3>
                            <p>Masukkan data produk</p>
                        </div>
                    </div>
                    <div class="row">
                        <?php echo form_open_multipart('produk/insert'); ?>
                              <div class="form-group">
                                  <label>Nama Produk</label>
                                  <input type="text" class="form-control" name="nama_produk" value="<?php echo $key->nama_produk ?>">
                              </div>
                              <div class="form-group">
                                  <label>keterangan</label>
                                  <input type="text" class="form-control" name="keterangan"value="<?php echo $key->keterangan ?>">
                              </div>
                              <div class="form-group">
                                  <label>Harga</label>
                                  <input type="number" class="form-control" name="harga" value="<?php echo $key->harga ?>">
                              </div>
                              <div class="form-group">
                                  <label>Jumlah</label>
                                  <input type="number" class="form-control" name="jumlah" value="<?php echo $key->jummlah ?>">
                              </div>
                              <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End form-produk Section -->

    </body>

</html>
