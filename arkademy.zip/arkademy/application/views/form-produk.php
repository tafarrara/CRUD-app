<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Arkademy</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo base_url('asset/css/bootstrap.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/animate.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/style.css') ?>" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet" type='text/css'>

        <!-- Template js -->
        <script src="<?php echo base_url('asset/js/jquery-2.1.1.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jquery.appear.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jqBootstrapValidation.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/modernizr.custom.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/script.js') ?>"></script>
    </head>

    <body>

       <!-- Start Feature Section -->
        <div class="section-modal" >
            <div class="">
                <div class="close-modal" data-dismiss="modal">
                    <a href="<?php $sesion = $this->session->userdata['produk']; echo base_url('produk/').$sesion ?>"><img src="<?php echo base_url('asset/images/close.png') ?>"></a>
                </div>

                <br><br>
                <div class="container">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3>Edit Produk</h3>

                        </div>
                    </div>
                    <br>  <br>
                    <div class="row">
                      <?php foreach ($produk as $key) { ?>
                        <form class="" action="<?php echo base_url('produk/update') ?>" method="post">
                              <div class="form-group">
                                  <label>Nama Produk</label>
                                  <input type="text" class="form-control" name="nama_produk" value="<?php echo $key->nama_produk ?>">
                              </div>
                              <div class="form-group">
                                  <label>keterangan</label>
                                  <input type="text" class="form-control" name="keterangan"value="<?php echo $key->keterangan ?>">
                              </div>
                              <div class="form-group">
                                  <label>Harga</label>
                                  <input type="number" class="form-control" name="harga" value="<?php echo $key->harga ?>">
                              </div>
                              <div class="form-group">
                                  <label>Jumlah</label>
                                  <input type="number" class="form-control" name="jumlah" value="<?php echo $key->jummlah ?>">
                              </div>
                              <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                      <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Form-Login Section -->
    </body>
</html>
