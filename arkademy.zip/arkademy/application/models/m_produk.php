<?php
class m_produk extends CI_Model{

	function tampil_data(){
		return $this->db->get('produk');
	}

	function get_prod(){
		$where = array('SubMenu' => 'prod');
		return $this->db->get_where('produk',$where);
	}

	function input_data($data, $table){
		$this->db->insert($table, $data);
	}

	function get_file($id)
	{
		$this->db->from('produk');
		$this->db->where($id);
		$query = $this->db->get();

		//cek apakah ada data
		if ($query->num_rows() == 1) {
				return $query->row();
		}
	}

	function hapus_data($id,$table){
		$this->db->where($id);
		$this->db->delete($table);
	}

	function edit_data($where,$table){
		return $this->db->get_where($table,$where);
	}

	function update_data($where, $data, $table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

}

?>
