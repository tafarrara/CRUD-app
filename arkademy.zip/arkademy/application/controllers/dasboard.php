<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class dasboard extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('m_login');
    }

    public function index() {
        $this->load->view('Index');
    }

    function login(){
    	$this->load->view('form-login');
    }

    function cek_login() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $where = array(
            'username' => $username,
            'password' => md5($password)
        );
        $cek = $this->m_login->cek_login("user", $where)->num_rows();
        if ($cek > 0) {

            $data_session = array(
                'nama' => $username,
            );

            $this->session->set_userdata('login', $data_session);

            echo '<script>
			  alert("Welcome");
			  window.location = "http://localhost/arsipadhi/";
			</script>';


        } else {
            echo '<script>alert("Login Gagal"); window.location ="login"</script>';
        }
    }

    function logout() {
        $this->session->sess_destroy();
        echo '<script>
			  alert("Good Bye");
			  window.location = "http://localhost/arsipadhi/";
			</script>';
    }



}
