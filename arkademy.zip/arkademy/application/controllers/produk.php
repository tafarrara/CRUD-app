<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class produk extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('m_produk');
    }

    public function index() {
        $this->load->view('Menu_produk');
    }
    public function prod() {
        $this->session->set_userdata('produk', 'prod');
        $data['produk'] = $this->m_produk->get_prod()->result();
        $this->load->view('V_produk', $data);
    }

    function insert() {
        $nama_produk = $this->input->post('nama_produk');
        $keterangan = $this->input->post('keterangan');
        $harga = $this->input->post('harga');
        $jumlah = $this->input->post('jumlah');

        $data = array(
            'nama_produk' => $nama_produk,
            'keterangan' => $keterangan,
            'harga' => $harga,
            'jumlah' => $jumlah
        );
        $this->m_produk->input_data($data, 'produk');
        $redirec = "produk/". strtolower($submenu);
        redirect($redirec);
    }

    public function edit($id) {
        $where = array('id' => $id);
        $data['produk'] = $this->m_produk->edit_data($where, 'produk')->result();
        $this->load->view('form-produk', $data);
    }

    public function update() {
        $id = $this->input->post('id');
        $nama_produk = $this->input->post('nama_produk');
        $keterangan = $this->input->post('keterangan');
        $harga = $this->input->post('harga');
        $jumlah = $this->input->post('jumlah');

        $data = array(
          'nama_produk' => $nama_produk,
          'keterangan' => $keterangan,
          'harga' => $harga,
          'jumlah' => $jumlah
        );

        $where = array(
            'id' => $id
        );

        $this->m_produk->update_data($where, $data, 'produk');
        $redirec = "produk/". strtolower($submenu);
        redirect($redirec);
    }

    function hapus($id) {

        $path= './uploads/';
        $id = array('id' => $id);
        $row = $this->m_produk->get_file($id);
        @unlink($path.$row->File.'.pdf');

        $this->m_produk->hapus_data($id, 'produk');
        $submenu = $this->session->userdata['produk'];
        $redirec = "produk/". strtolower($submenu);
        redirect($redirec);
    }

}

?>
